Extract all files from this folder. 

Once extracted, find the file in MonitortV2_x.x.x folder named "Main" with a letter S as it's icon.
Run that file, once ran there is more help on there! Goodluck.